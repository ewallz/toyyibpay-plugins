<?php

/**
 * ToyyibPay OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author ToyyibPay Team
 */
 
require_once __DIR__ .'/toyyibpay-api.php';

class ControllerExtensionPaymentToyyibpay extends Controller
{

    public function index()
    {
        $this->load->language('extension/payment/toyyibpay');
        $data['button_confirm'] = $this->language->get('button_confirm');
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        //$data['country'] = $order_info['payment_iso_code_2'];
        //$data['currency'] = $order_info['currency_code'];
        $products = $this->cart->getProducts();
        foreach ($products as $product) {
            $data['prod_desc'][] = $product['name'] . " x " . $product['quantity'];
        }
        //$data['lang'] = $this->session->data['language'];

        $amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $_SESSION['name'] = $order_info['payment_firstname'] . ' ' . $order_info['payment_lastname'];
        $_SESSION['email'] = empty($order_info['email']) ? '' : $order_info['email'];
        $_SESSION['description'] = "Order " . $this->session->data['order_id'] . " - " . implode($data['prod_desc']);
        $_SESSION['mobile'] = empty($order_info['telephone']) ? '' : $order_info['telephone'];

        $_SESSION['order_id'] = $this->session->data['order_id'];
        $_SESSION['amount'] = $amount;
        $_SESSION['redirect_url'] = $this->url->link('extension/payment/toyyibpay/return_ipn', '', true);
        $_SESSION['callback_url'] = $this->url->link('extension/payment/toyyibpay/callback_ipn', '', true);
        $_SESSION['delivery'] = $this->config->get('payment_toyyibpay_delivery'); //0-4
        $data['action'] = $this->url->link('extension/payment/toyyibpay/proceed', '', true);

        return $this->load->view('extension/payment/toyyibpay', $data);
    }

    public function proceed()
    {

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $api_key = $this->config->get('payment_toyyibpay_api_key_value');
        $category_code = $this->config->get('payment_toyyibpay_category_code_value');

        $deliver = $_SESSION['delivery'];
        $name = empty(trim($_SESSION['name'])) ? 'NAME' : $_SESSION['name'];
        $email = $_SESSION['email'];
        $description = $_SESSION['description'];
        $mobile = $_SESSION['mobile'];
        $ext_ref_no = $_SESSION['order_id'];
        $amount = preg_replace("/[^0-9.]/", "", $_SESSION['amount']) * 100;
        $redirect_url = $_SESSION['redirect_url'];
        $callback_url = $_SESSION['callback_url'];

        unset($_SESSION['name']);
        unset($_SESSION['email']);
        unset($_SESSION['description']);
        unset($_SESSION['mobile']);
        unset($_SESSION['order_id']);
        unset($_SESSION['amount']);
        unset($_SESSION['redirect_url']);
        unset($_SESSION['callback_url']);
        unset($_SESSION['delivery']);

		$parameter = array(
			'userSecretKey'=> $api_key,
			'categoryCode'=> $category_code,
			'billName'=> $name,
			'billDescription'=> $description,
			'billPriceSetting'=>1,
			'billPayorInfo'=>1, 
			'billAmount'=> $amount, 
			'billReturnUrl'=> $redirect_url,
			'billCallbackUrl'=> $callback_url,
			'billExternalReferenceNo'=> $ext_ref_no,
			'billTo'=> $name,
			'billEmail'=> $email,
			'billPhone'=> $mobile,
			'billSplitPayment'=>0,
			'billSplitPaymentArgs'=>'',
			'billPaymentChannel'=>2
		);

        $toyyibpay = new ToyyibPayAPI(trim($api_key));
		$createBill = $toyyibpay->createBill($parameter);

		if ($createBill['header'] !== 200) {
			//Curl not response
            throw new Exception("Error connection to toyyibpay!");
            exit;
		}

		if ( empty($createBill['body']['BillCode']) ) {
			//BillCode Not Exist
            throw new Exception("BillCode not return!");
            exit;
		}

		//echo "<script>alert('123');</script>";
		//echo "<script>alert('".$createBill['body']['BillURL'] ."');</script>";
		
        header('Location: ' . $createBill['body']['BillURL'] );
    }

    public function return_ipn()
    {
        $this->load->model('checkout/order');

        $api_key = $this->config->get('payment_toyyibpay_api_key_value');
        $toyyibpay = new ToyyibPayAPI(trim($api_key));
		$data = $toyyibpay->getTransactionData();	
        
        $orderid = $data['order_id'];
        $status = $data['paid'];
        $amount = $data['amount'];
        $orderHistNotes = "Redirect: " . date(DATE_ATOM) . " BillCode:" . $data['billcode'] . " Status:" . $data['status_name'];
		
        $order_info = $this->model_checkout_order->getOrder($orderid); // orderid

        if ($status) {
            $order_status_id = $this->config->get('payment_toyyibpay_completed_status_id');
        } elseif (!$status) {
            $order_status_id = $this->config->get('payment_toyyibpay_failed_status_id');
        }
        else {
        	$order_status_id = $this->config->get('payment_toyyibpay_pending_status_id');
        }

        if (!$order_info['order_status_id'])
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id, $orderHistNotes, false);
        else {
            /*
             * Prevent same order status id from adding more than 1 update
             */
            if ($order_status_id != $order_info['order_status_id'])
                $this->model_checkout_order->addOrderHistory($orderid, $order_status_id, $orderHistNotes, false);
        }

        /*
         * Determine which page the buyer should go based on
         * payment status
         */

        if ($status)
            $goTo = $this->url->link('checkout/success');
        else
            $goTo = $this->url->link('checkout/checkout');

        if (!headers_sent()) {
            header('Location: ' . $goTo);
        } else {
            echo "If you are not redirected, please click <a href=" . '"' . $goTo . '"' . " target='_self'>Here</a><br />"
            . "<script>location.href = '" . $goTo . "'</script>";
        }

        exit();
    }
    /*     * ***************************************************
     * Callback with IPN(Instant Payment Notification)
     * **************************************************** */

    public function callback_ipn()
    {
        $this->load->model('checkout/order');
        
        $api_key = $this->config->get('payment_toyyibpay_api_key_value');
        $toyyibpay = new ToyyibPayAPI(trim($api_key));
		$data = $toyyibpay->getTransactionData();
		
        $orderid = $data['order_id'];
        $status = $data['paid'];
        $amount = $data['amount'];
        $orderHistNotes = "Callback: " . date(DATE_ATOM) . " BillCode:" . $data['billcode'] . " Status:" . $data['status_name'];
		
        $order_info = $this->model_checkout_order->getOrder($orderid); // orderid

        if ($status) {
            $order_status_id = $this->config->get('payment_toyyibpay_completed_status_id');
        } elseif (!$status) {
            $order_status_id = $this->config->get('payment_toyyibpay_pending_status_id');
        }
        if (!$order_info['order_status_id']) {
            $this->model_checkout_order->addOrderHistory($orderid, $order_status_id, $orderHistNotes, false);
        } else {
            /*
             * Prevent same order status id from adding more than 1 update
             */
            if ($order_status_id != $order_info['order_status_id'])
                $this->model_checkout_order->addOrderHistory($orderid, $order_status_id, $orderHistNotes, false);
        }
        exit('Callback Success');
    }
}
