<?php

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToyyibPay extends PaymentModule
{
    protected $_html = '';
    protected $_postErrors = array();

    protected $api_key;
    protected $category_code;

    public function __construct()
    {
        $this->name = 'toyyibpay';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->ps_versions_compliancy = array('min' => '1.7.5.0', 'max' => '1.7');
        //$this->limited_countries = array('my');
        $this->author = 'ToyyibPay Sdn. Bhd.';
        $this->controllers = array('return', 'validation');
        $this->is_eu_compatible = 0;

        $this->currencies = true;
        $this->currencies_mode = 'radio';

        $config = Configuration::getMultiple(array('TOYYIBPAY_API_KEY', 'TOYYIBPAY_CATEGORY_CODE'));

        if (!empty($config['TOYYIBPAY_API_KEY'])) {
            $this->api_key = $config['TOYYIBPAY_API_KEY'];
        }

        if (!empty($config['TOYYIBPAY_CATEGORY_CODE'])) {
            $this->category_code = $config['TOYYIBPAY_CATEGORY_CODE'];
        }

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('ToyyibPay', array(), 'Modules.ToyyibPay.Admin');
        $this->description = $this->trans('Accept payments by ToyyibPay.', array(), 'Modules.ToyyibPay.Admin');
        $this->confirmUninstall = $this->trans('Are you sure about removing these details?', array(), 'Modules.ToyyibPay.Admin');

        if (!isset($this->api_key) || !isset($this->category_code)) {
            $this->warning = $this->trans('API Key and Category Code must be configured before using this module.', array(), 'Modules.ToyyibPay.Admin');
        }

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->trans('No currency has been set for this module.', array(), 'Modules.ToyyibPay.Admin');
        }
    }

    public function install()
    {
        Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'toyyibpay` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `cart_id` int(11) NOT NULL,
                `bill_id` varchar(255) NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;'
        );
        
        if (!parent::install() || !$this->registerHook('paymentReturn') || !$this->registerHook('paymentOptions') || !$this->installOrderState()) {
            return false;
        }
        return true;
    }

    public function installOrderState()
    {
        if (!Configuration::get('TOYYIBPAY_OS_WAITING') || !Validate::isLoadedObject(new OrderState(Configuration::get('TOYYIBPAY_OS_WAITING')))) {
            $order_state = new OrderState();
            $order_state->name = array();
            foreach (Language::getLanguages() as $language) {
                $order_state->name[$language['id_lang']] = 'Awaiting for ToyyibPay payment';
            }

            $order_state->send_email = false;
            $order_state->color = '#4169E1';
            $order_state->hidden = false;
            $order_state->delivery = false;
            $order_state->logable = false;
            $order_state->invoice = false;
            if ($order_state->add()) {
                $source = _PS_MODULE_DIR_.'toyyibpay/logo.png';
                $destination = _PS_ROOT_DIR_.'/img/os/'.(int) $order_state->id.'.gif';
                copy($source, $destination);
            }

            Configuration::updateValue('TOYYIBPAY_OS_WAITING', (int) $order_state->id);
        }
        return true;
    }

    public function uninstall()
    {
        if (!Configuration::deleteByName('TOYYIBPAY_API_KEY')
            || !Configuration::deleteByName('TOYYIBPAY_CATEGORY_CODE')
            || !parent::uninstall()) {
            return false;
        }

        return true;
    }

    protected function _postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('TOYYIBPAY_API_KEY')) {
                $this->_postErrors[] = $this->trans('API Key are required.', array(), 'Modules.ToyyibPay.Admin');
            } elseif (!Tools::getValue('TOYYIBPAY_CATEGORY_CODE')) {
                $this->_postErrors[] = $this->trans('Category Code is required.', array(), "Modules.ToyyibPay.Admin");
            }
        }
    }

    protected function _postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('TOYYIBPAY_API_KEY', Tools::getValue('TOYYIBPAY_API_KEY'));
            Configuration::updateValue('TOYYIBPAY_CATEGORY_CODE', Tools::getValue('TOYYIBPAY_CATEGORY_CODE'));
        }
        $this->_html .= $this->displayConfirmation($this->trans('Settings updated', array(), 'Admin.Global'));
    }

    public function getContent()
    {
        if (Tools::isSubmit('btnSubmit')) {
            $this->_postValidation();
            if (!count($this->_postErrors)) {
                $this->_postProcess();
            } else {
                foreach ($this->_postErrors as $err) {
                    $this->_html .= $this->displayError($err);
                }
            }
        } else {
            $this->_html .= '<br />';
        }

        $this->_html .= $this->renderForm();
        return $this->_html;
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $newOption = new PaymentOption();
        $newOption->setModuleName($this->name)
                ->setCallToActionText($this->trans('Pay by ToyyibPay', array(), 'Modules.ToyyibPay.Shop'))
                ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true));
        
        $payment_options = [
            $newOption,
        ];

        return $payment_options;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }
    }

    public function checkCurrency($cart)
    {
        if (!(int) $current_id_currency) {
            $current_id_currency = Context::getContext()->currency->id;
        }

        if (!$this->currencies) {
            return false;
        }

        $currencies_module = Currency::getPaymentCurrencies($this->id);
        $currency_order = new Currency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }

        return false;
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans('ToyyibPay account details', array(), 'Modules.ToyyibPay.Admin'),
                    'icon' => 'icon-gear'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->trans('API Secret Key', array(), 'Modules.ToyyibPay.Admin'),
                        'name' => 'TOYYIBPAY_API_KEY',
                        'desc' => $this->trans('It can be from Production or Staging. It can be retrieved from ToyyibPay dashboard page.', array(), 'Modules.ToyyibPay.Admin'),
                        'required' => true
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->trans('Category Code', array(), 'Modules.ToyyibPay.Admin'),
                        'name' => 'TOYYIBPAY_CATEGORY_CODE',
                        'desc' => $this->trans('Enter your chosen specific Billing Category Code. It can be retrieved from ToyyibPay Category page.', array(), 'Modules.ToyyibPay.Admin'),
                        'required' => true
                    )
                ),
                'submit' => array(
                    'title' => $this->trans('Save', array(), 'Admin.Actions'),
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='
            .$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );

        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        return array(
            'TOYYIBPAY_API_KEY' => Tools::getValue('TOYYIBPAY_API_KEY', Configuration::get('TOYYIBPAY_API_KEY')),
            'TOYYIBPAY_CATEGORY_CODE' => Tools::getValue('TOYYIBPAY_CATEGORY_CODE', Configuration::get('TOYYIBPAY_CATEGORY_CODE'))
        );
    }
}
