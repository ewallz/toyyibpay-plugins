<?php

require_once _PS_MODULE_DIR_ . 'toyyibpay/classes/toyyibpayAPI.php';

class ToyyibpayValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $authorized = false;

        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'toyyibpay') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized) {
            die($this->module->getTranslator()->trans('This payment method is not available.', array(), 'Modules.ToyyibPay.Shop'));
        }

        $customer = new Customer($cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        $id_address = (int) $cart->id_address_delivery;
        if (($id_address == 0) && ($customer)) {
            $id_address = Address::getFirstCustomerAddressId($customer->id);
        }

        $address = new Address($id_address);

        $currency = $this->context->currency;
        $total = $cart->getOrderTotal(true, Cart::BOTH);

        $config = Configuration::getMultiple(array('TOYYIBPAY_API_KEY', 'TOYYIBPAY_CATEGORY_CODE'));

        $products = $cart->getProducts();
        $product_description = '';
        foreach ($products as $product) {
            $product_description.="{$product['name']} ";
        }
		
		$parameter = array(
			'userSecretKey'=> trim($config['TOYYIBPAY_API_KEY']),
			'categoryCode'=> trim($config['TOYYIBPAY_CATEGORY_CODE']),
			'billName'=> trim($customer->firstname . " " . $customer->lastname),
			'billDescription'=> mb_substr($product_description, 0, 200),
			'billPriceSetting'=>1,
			'billPayorInfo'=>1, 
			'billAmount'=> strval($total * 100),
			'billReturnUrl'=> $this->context->link->getModuleLink($module['name'], 'return', array(), true),
			'billCallbackUrl'=> $this->context->link->getModuleLink($module['name'], 'return', array(), true),
			'billExternalReferenceNo'=> $cart->id .'||'. $order_id,
			'billTo'=> trim($customer->firstname . " " . $customer->lastname),
			'billEmail'=> trim($customer->email),
			'billPhone'=> trim((empty($address->phone)) ? $address->phone_mobile : $address->phone),
			'billSplitPayment'=>0,
			'billSplitPaymentArgs'=>'',
			'billPaymentChannel'=>2
		);

        if (empty($parameter['billEmail'])) {
            $parameter['billEmail'] = 'noreply@toyyibpay.com';
        }
        if (empty($parameter['billPhone'])) {
            $parameter['billPhone'] = '60';
        }
        if (empty($parameter['billName'])) {
            $parameter['billName'] =  !empty($blog_name) ? $blog_name : 'Payer Name Unavailable';
        }
        if (empty($parameter['billTo'])) {
            $parameter['billTo'] =  !empty($blog_name) ? $blog_name : 'Payer Name Unavailable';
        }

        $this->module->validateOrder($cart->id, Configuration::get('TOYYIBPAY_OS_WAITING'), '0.0', $this->module->displayName, "", array(), (int)$currency->id, false, $customer->secure_key);

        $order_id = Order::getIdByCartId($cart->id);

		$parameter['billExternalReferenceNo'] = $cart->id .'||'. $order_id;

        $toyyibpay = new ToyyibPayAPI(trim($config['TOYYIBPAY_API_KEY']));
		list($rheader, $rbody) = $toyyibpay->createBill($parameter);

        if ($rheader !== 200) {
            Tools::redirect('index.php?controller=order&step=1');
        }

        Db::getInstance()->insert(
            'toyyibpay',
            array(
                'cart_id' => pSQL((int) $cart->id),
                'bill_id' => pSQL($rbody[0]['BillCode']),
            )
        );

        Tools::redirect($rbody[0]['BillURL']);
    }
}
