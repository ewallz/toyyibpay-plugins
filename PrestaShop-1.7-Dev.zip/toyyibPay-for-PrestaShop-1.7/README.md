# ToyyibPay for PrestaShop 1.7
Accept payment using ToyyibPay for PrestaShop 1.7

## Installation
1. Download zip file
3. **Open** the archive and **rename** the folder inside from **toyyibpay-for-Prestashop** to **toyyibpay**.
4. Upload and **Install to Prestashop**.
5. Set your **API Key & Category code**.
6. Set ToyyibPay Currency restrictions to Malaysian Ringgit (MYR).
7. Done.

## System Requirements
1. PHP 7.0 or later.
2. Prestashop **1.7.x**.
3. **Not compatible with Prestashop 1.6** and below.

# Other

