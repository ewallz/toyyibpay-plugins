# ToyyibPay-for-OpenCart 1.5.x
Accept Payment using ToyyibPay for OpenCart 1.5.x

# Plugin Version History
* 1.0.0 Build 201906181200 : Release dev & prod version

# Installation
1. Download and extract to installation directory
2. Install
3. Configure API Key, Collection ID
4. Hola, you are done!

