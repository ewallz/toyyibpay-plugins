<?php
/**
 * ToyyibPay OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author ToyyibPay Team
 * @version 1.5.0
 */
 
// Text
$_['text_title'] = 'ToyyibPay Malaysia Online Payment Gateway';