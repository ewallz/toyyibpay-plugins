=== ToyyibPay for GiveWP ===
Contributors: ToyyibpayTeam
Tags: toyyibpay,paymentgateway,fpx,mastercard,visa,malaysia
Requires at least: 4.2
Tested up to: 4.8.2
Stable tag: 3.0.2
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

ToyyibPay Add-on for Give

== Description ==

Add payment gateway for ToyyibPay.

== Changelog ==

* 1.0.2 Build 201909230945 : Release prod version
* 1.0.1 Build 201909222110 : Fix bugs for dev
* 1.0.0 Build 201909191140 : Init Release
