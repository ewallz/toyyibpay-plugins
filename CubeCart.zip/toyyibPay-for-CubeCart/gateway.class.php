<?php

/**
 * CubeCart v6
 * ========================================
 * CubeCart is a registered trade mark of CubeCart Limited
 * Copyright CubeCart Limited 2014. All rights reserved.
 * UK Private Limited Company No. 5323904
 * ========================================
 * Web:   http://www.cubecart.com
 * Email:  sales@cubecart.com
 * License:  GPL-3.0 http://opensource.org/licenses/GPL-3.0
 */
require_once __DIR__ . '/includes/toyyibpay.php';

class Gateway {

    private $_config;
    private $_module;
    private $_basket;

    public function __construct($module = false, $basket = false) {
        $this->_config = & $GLOBALS['config'];
        $this->_session = & $GLOBALS['user'];

        $this->_module = $module;
        $this->_basket = & $GLOBALS['cart']->basket;
    }

    ##################################################

    public function transfer() {

        $name = $this->_basket['billing_address']['first_name'] . ' ' . $this->_basket['billing_address']['last_name'];
        $email = $this->_basket['billing_address']['email'];
        $mobile = $this->_basket['billing_address']['phone'];
        $deliver = $this->_module['send_bill'];
        $category_code = $this->_module['category_code'];
        $order_id = $this->_basket['cart_order_id'];
        $description = $this->_module['toyyibpay_description'];
        $plugin_folder_name = basename(__DIR__);
        $callback_url = $GLOBALS['storeURL'] . '/index.php?_g=rm&type=gateway&cmd=call&module='.$plugin_folder_name;

		$parameter = array(
			'userSecretKey'=> $this->_module['api_key'],
			'categoryCode'=> $category_code,
			'billName'=> $name,
			'billDescription'=> $description,
			'billPriceSetting'=>1,
			'billPayorInfo'=>1, 
			'billAmount'=> ( preg_replace("/[^0-9.]/", "", $this->_basket['total']) * 100 ),
			'billReturnUrl'=> $callback_url,
			'billCallbackUrl'=> $callback_url,
			'billExternalReferenceNo'=> $order_id,
			'billTo'=> $name,
			'billEmail'=> $email,
			'billPhone'=> $mobile,
			'billSplitPayment'=>0,
			'billSplitPaymentArgs'=>'',
			'billPaymentChannel'=>2
		);
        $toyyibpay = new ToyyibPayAPI(trim($this->_module['api_key']));
		$createBill = $toyyibpay->createBill($parameter);

        $transfer = array(
            'action' => $createBill['body']['BillCode'],
            'method' => 'get',
            'target' => '_self',
            'submit' => 'auto',
        );
        return $transfer;
    }

    public function repeatVariables() {
        return false;
    }

    public function fixedVariables() {
        return false;
    }

    ##################################################

    public function call() {

        if (substr(CC_VERSION, 0, 1) == '6' || $GLOBALS['db']->count('CubeCart_modules', 'module_id', array('module' => 'gateway', 'status' => '1')) == 1) {
            $cancel_return = 'confirm';
        } else {
            $cancel_return = 'gateway';
        }
 
        $api_key = $this->_module['api_key'];
		$toyyibpay = new ToyyibPayAPI($api_key);
		$data = $toyyibpay->getTransactionData();
		
		/* $signkey = $this->_module['x_signature'];
        if (isset($_GET['toyyibpay']['id'])) {
            $data = ToyyibPay::getRedirectData($signkey);
        } else if (isset($_POST['id'])) {
            $data = ToyyibPay::getCallbackData($signkey);
            sleep(10);
        } else {
            exit;
        } */

        //$toyyibpay = new ToyyibPay($api_key);
       // $moreData = $toyyibpay->check_bill($data['id']);

        $cart_order_id = $data['order_id'];

        $order = Order::getInstance();
        $order_summary = $order->getSummary($cart_order_id);
        $transData['notes'] = array();

        if ($data['paid']) {
            $transData['notes'][] = "Payment successful. <br />Bill Code: " . $data['billcode'] . "<br />Transaction ID: " . $data['transaction_id'] . "<br />Status: " . strtoupper($data['status_id']);
			
            /*
             * Prevent from updating twice
             */
            if ($order_summary['status'] === '2') {
                $transData['notes'] = 'Ignoring duplicate callback.';
            } else {
                $transData['bill_id_status'] = $data['billcode'] . 'paid';
                $order->paymentStatus(Order::PAYMENT_SUCCESS, $cart_order_id);
                $order->orderStatus(Order::ORDER_PROCESS, $cart_order_id);
            }
        } else {
			$transData['notes'][] = "Payment Cancelled. <br />Bill Code: " . $data['billcode'] . "<br />Transaction ID: " . $data['transaction_id'] . "<br />Status: " . strtoupper($data['status_id']);
			
            $order->paymentStatus(Order::PAYMENT_CANCEL, $cart_order_id);
            $order->orderStatus(Order::ORDER_CANCELLED, $cart_order_id);
        }

        $transData['gateway'] = 'ToyyibPay';
        $transData['order_id'] = $cart_order_id;
        $transData['bill_id'] = $data['billcode'];
        $transData['paid_amount'] = number_format($data['amount'] / 100, 2);
        $transData['amount'] = number_format($data['amount'] / 100, 2);
        $transData['status'] = $data['status_name'];
        $transData['customer_id'] = $order_summary['customer_id'];
        $order->logTransaction($transData);

        if (isset($_GET['toyyibpay']['id'])) {
            if ($data['paid']) {
                $this->goToRedirect($GLOBALS['storeURL'] . '/index.php?_a=complete');
            } else {
                $this->goToRedirect($GLOBALS['storeURL'] . '/index.php?_a=' . $cancel_return);
            }
        } else {
            echo 'OK';
        }
        return false;
    }

    private function goToRedirect($url) {
        if (!headers_sent()) {
            header('Location: ' . $url);
        } else {
            echo "If you are not redirected, please click <a href=" . '"' . $url . '"' . " target='_self'>Here</a><br />"
            . "<script>location.href = '" . $url . "'</script>";
        }
    }

    public function process() {
        ## We're being returned from ToyyibPay - This function can do some pre-processing, but must assume NO variables are being passed around
        ## The basket will be emptied when we get to _a=complete, and the status isn't Failed/Declined
        ## Redirect to _a=complete, and drop out unneeded variables
        httpredir(currentPage(array('_g', 'type', 'cmd', 'module'), array('_a' => 'complete')));
    }

    public function form() {
        return false;
    }

}
