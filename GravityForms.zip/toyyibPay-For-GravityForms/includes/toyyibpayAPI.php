<?php

class ToyyibPayGravityFormsAPI
{
    private $api_key;
    private $x_signature_key;
    private $category_code;

    private $process;
    public $is_production;
    public $url;

    public $header;

    const TIMEOUT = 10; //10 Seconds
    const PRODUCTION_URL = 'https://toyyibpay.com/';
    const STAGING_URL = 'https://dev.toyyibpay.com/';

    public function __construct($api_key)
    {
        $this->api_key = $api_key;
        $this->header = array(
            'Authorization' => 'Basic ' . base64_encode($this->api_key . ':')
        );
    }

    public function setMode($is_production = true)
    {
        $this->is_production = $is_production;
        if ($is_production) {
            $this->url = self::PRODUCTION_URL;
        } else {
            $this->url = self::STAGING_URL;
        }
		return $this;
    }

    public function createCategory($title='Payment For Purchase From GravityForm', $description='')
    {
		$data = array(
			'catname' => $title,
			'catdescription' => $description,
			'userSecretKey' => $this->api_key
		);
		$this->setActionURL('CREATECATEGORY'); 
		$result = $this->submitAction($data);
		$category = json_decode($result[1],true); 
		
		if(is_array($category[0])) {
			return $category[0]['CategoryCode'];
		}
		else {
			return $category['CategoryCode'];
		}
    }
	
    public function checkCategory($id)
    {
		$data = array(
			'CategoryCode' => $id,
			'userSecretKey' => $this->api_key
		);
		$this->setActionURL('CHECKCATEGORY'); 
		$result = $this->toArray($this->submitAction($data)); 

        return $result[1];
    }
	
    public function createBill($parameter)
    {
        /* Email or Mobile must be set */
        if (empty($parameter['billEmail']) && empty($parameter['billPhone'])) {
            throw new \Exception("Email or Mobile must be set!");
        }

        /* Validate Mobile Number first */
        if (!empty($parameter['billPhone'])) {
            /* Strip all unwanted character */
            $parameter['billPhone'] = preg_replace('/[^0-9]/', '', $parameter['billPhone']);

            /* Add '6' if applicable */
            $parameter['billPhone'] = $parameter['billPhone'][0] === '0' ? '6'.$parameter['billPhone'] : $parameter['billPhone'];

            /* If the number doesn't have valid formatting, reject it */
            /* The ONLY valid format '<1 Number>' + <10 Numbers> or '<1 Number>' + <11 Numbers> */
            /* Example: '60141234567' or '601412345678' */
            if (!preg_match('/^[0-9]{11,12}$/', $parameter['billPhone'], $m)) {
                $parameter['billPhone'] = '';
            }
        }
		
		/* Check Category Code that has been entered is valid or not. If invalid, unset categoryCode */
		/* 
		if ( isset($parameter['categoryCode']) ) {
			$status = $this->checkCategory($parameter['categoryCode']);
			if (!$status)
				unset($parameter['categoryCode']);
		} 
		*/

		/* If not set, get Category Code */
		// if (!isset($parameter['categoryCode'])) {
		if(empty($parameter['categoryCode'])) {
			$parameter['categoryCode'] = $this->createCategory();
		}
		
		//Last Check
		if (empty($parameter['categoryCode'])) {
			throw new \Exception("Category Code Not Found! ");
		}
		
		//Create Verification Code
		//$vcode = md5($parameter['userSecretKey'].$parameter['categoryCode'].$parameter['billAmount']);
		$vcode = md5($parameter['userSecretKey'].$parameter['billExternalReferenceNo'].$parameter['billAmount']);
		$parameter['billReturnUrl'] = $this->setUrlQuery($parameter['billReturnUrl'],array('vc'=>$vcode));
		$parameter['billCallbackUrl'] = $this->setUrlQuery($parameter['billCallbackUrl'],array('vc'=>$vcode));
		
        /* Create Bills */
		$this->setActionURL('CREATEBILL');	
		$bill = $this->toArray($this->submitAction($parameter)); 
		$billdata = $this->setPaymentURL($bill); 
		
        return $billdata;
    }
	
    public function setPaymentURL($bill)
    {
		if( isset($bill[1][0]['BillCode']) ) {
			$this->setActionURL('PAYMENT', $bill[1][0]['BillCode'] ); 
			$bill[1][0]['BillURL'] = $this->url;
		}
		$return = array($bill[0],$bill[1][0]);
		
			$checkData = array(
				'Request'=> json_encode($bill),
				'RespBody'=> json_encode($return)
			);
			$this->temp_dev_action_check($checkData);
		
		return $return;		
    }	
	
    public function checkBill($parameter)
    {
		$this->setActionURL('CHECKBILL');
		$checkData = $this->toArray($this->submitAction($parameter)); 
		
		return array($checkData[0],$checkData[1][0]);	
    }
	
    public function deleteBill($parameter)
    {
		$this->setActionURL('DELETEBILL');
		$checkData = $this->toArray($this->submitAction($parameter)); 
		
		return array($checkData[0],$checkData[1][0]);	
    }

    public function setUrlQuery($url,$data)
    {
		if (!empty($url)) {
			if( count( explode("?",$url) ) > 1 )  
				$url = $url .'&'. http_build_query($data);
			else  
				$url = $url .'?'. http_build_query($data);
		}
		return $url;
    }

    public function getTransactionData()
    {
		if (isset($_GET['billcode']) && isset($_GET['transaction_id']) && isset($_GET['order_id']) && isset($_GET['status_id'])) {

			$data = array(
				'status_id' => $_GET['status_id'],
				'billcode' => $_GET['billcode'],
				'order_id' => $_GET['order_id'],
				'msg' => $_GET['msg'],
				'transaction_id' => $_GET['transaction_id']
			);
            $type = 'redirect';
			
        } elseif ( isset($_POST['refno']) && isset($_POST['status']) && isset($_POST['amount']) ) {

			$data = array(
				'status_id' => $_POST['status'],
				'billcode' => $_POST['billcode'],
				'order_id' => $_POST['order_id'],
				'amount' => $_POST['amount'],
				'reason' => $_POST['reason'],
				'transaction_id' => $_POST['refno']
			);
            $type = 'callback';
			
        } else {
            return false;
        }
		
			$checkData = array(
				'Request'=> json_encode(array('GET'=>$_GET,'POST'=>$_POST),true),
				'RespBody'=> json_encode($data)
			);
			$checkAction = ($type=='redirect'?'RETURNREDIRECT':($type=='callback'?'RETURNCALLBACK':''));
			$this->temp_dev_action_check($checkData,$checkAction);
		
		if( $type === 'redirect' ) {
			//check bill
			$parameter = array(
				'billCode' => $data['billcode'],
				'billExternalReferenceNo' => $data['order_id']
			);
			list($rheader, $rbody)= $this->checkBill($parameter);
			if ($rheader == 200) {
				if($rbody['billpaymentStatus'] != $data['status_id']) {
					$data['status_id'] = $rbody['billpaymentStatus'];
				}
				$data['amount'] = $rbody['billpaymentAmount'];
			}
		}
		
		$data['paid'] = $data['status_id'] === '1' ? true : false; /* Convert paid status to boolean */
		
		if( $data['status_id']=='1' ) $data['status_name'] = 'Success';
		else if( $data['status_id']=='2' ) $data['status_name'] = 'Pending';
		else $data['status_name'] = 'Unsuccessful';
		
		$data['vcode'] = $_GET['vc'];
		$amount = preg_replace("/[^0-9.]/", "", $data['amount']) * 100;
		$vcode = md5( $this->api_key . $data['order_id'] . $amount );
		
		if($data['vcode'] !== $vcode) {
			throw new \Exception('Verification Code Mismatch!');
		}
		
		$data['type'] = $type;
		return $data;
    }

	public function setActionURL($action, $id = '')
	{
		$this->setMode();
		$this->action = $action;
		
		if ($this->action == 'PAYMENT') {
			$this->url .= $id;
		}
		else if ($this->action == 'CREATECATEGORY') {
			$this->url .= 'index.php/api/createCategory';
		}
		else if ($this->action == 'CHECKCATEGORY') {
			$this->url .= 'index.php/api/createCategory';
		}
		else if ($this->action == 'CREATEBILL') {
			$this->url .= 'index.php/api/createBill';
		}
		else if ($this->action == 'CHECKBILL') {
			$this->url .= 'index.php/api/getBillTransactions';
		}
		else if ($this->action == 'DELETEBILL') {
			$this->url .= 'index.php/api/getBillTransactions';
		}
		else {
			throw new \Exception('URL Action not exist');
		}
		
		return $this;
	}
	
    public function submitAction($data='',$method='POST')
    {		
		$wp_remote_data['sslverify'] = false;
		$wp_remote_data['headers'] = $this->header;
		$wp_remote_data['body'] = http_build_query($data);
		$wp_remote_data['method'] = $method;

		$response = \wp_remote_post($this->url, $wp_remote_data);
		$header = $response['response']['code'];
		$body = \wp_remote_retrieve_body($response);
		$return = array($header,$body);
		
		$dataCheck = array(
			'Request'=> json_encode($data),
			'RespHeader'=> (is_array($header) ? json_encode($header) : $header),
			'RespBody'=> (is_array($body) ? json_encode($body) : $body)
		);
		/* $this->temp_dev_action_check($dataCheck); */
		
		return $return;
    }

	public function temp_dev_action_check($data='',$action='',$url='')
	{
		$param = array(
			'ACTION'=> ( $action=='' ? $this->action : $action ),
			'URL'=> ( $url=='' ? $this->url : $url )
		);
		if( is_array($data) ) $param = array_merge($param, $data);
		else $param['PARAMETER'] = json_encode($data);
		
		$checklogDev = curl_init();
		curl_setopt($checklogDev, CURLOPT_POST, 1);
		curl_setopt($checklogDev, CURLOPT_URL, 'http://52.76.166.8/paymentAPI/logs.php?JENISLOG=GRAVITYFORM' ); 
		curl_setopt($checklogDev, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($checklogDev, CURLOPT_POSTFIELDS, $param);
		$return = curl_exec($checklogDev);
		$info = curl_getinfo($checklogDev);  
		curl_close($checklogDev);
		
		return json_decode($return, true);
	}
	
    public function toArray($json)
    {
		// $data = json_decode($json[1],true);
		// if( json_last_error() == JSON_ERROR_NONE ) 
			// return $json;
		// else 
			return array($json[0], \json_decode($json[1], true));
    }
	
}
