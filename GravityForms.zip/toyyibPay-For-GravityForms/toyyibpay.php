<?php
/**
Plugin Name: ToyyibPay for GravityForms
Plugin URI: https://wordpress.org/plugins-wp/toyyibpay-for-gravityforms/
Description: ToyyibPay Payment Gateway | <a href="https://toyyibpay.com/access" target="_blank">Sign up Now</a>.
Version: 1.0.0
Author: ToyyibPay Sdn. Bhd.
Author URI: https://www.toyyibpay.com
License: GPL-2.0+
Text Domain: gravityformstoyyibpay
Domain Path: /languages
*/


define('GF_TOYYIBPAY_VERSION', '3.8.0');

add_action('gform_loaded', array( 'GF_ToyyibPay_Bootstrap', 'load' ), 5);

class GF_ToyyibPay_Bootstrap
{

    public static function load()
    {

        if (! method_exists('GFForms', 'include_payment_addon_framework')) {
            return;
        }

        include_once 'includes/toyyibpayAPI.php';
        include_once 'class-gf-toyyibpay.php';

        GFAddOn::register('GFToyyibPay');
    }
}

function gf_toyyibpay()
{
    return GFToyyibPay::get_instance();
}
