=== ToyyibPay for GravityForms ===
Contributors: ToyyibpayTeam
Tags: toyyibpay,paymentgateway,fpx,mastercard,visa,malaysia
Tested up to: 5.0.3
Stable tag: 3.8.1
Requires at least: 4.6
License: GPL-3.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 5.6

Accept Internet Banking Payment by using ToyyibPay.

== Description ==

Accept all participating Internet Banking, e-Wallet, Credit Cards and more with Gravity Forms! 

= Why choose ToyyibPay? =

ToyyibPay has no setup and monthly fees. Only pay as per payment received at RM1.50. You can also opt for a Preferred Plan @ RM1,500/month and save up to RM1.00 per payment received.

= How to register? =

[Apply now](https://toyyibpay.com/access) and submit the completed form to be registered and verified. The verification will be done automatically in 3 working days.

= Settlement policy =

Total daily collection (minimum RM0.01) shall be deposited automatically into the authorized bank account the next day (UTC+08:00 Kuala Lumpur) excluding Friday, Saturday, Sunday and Federal holidays. 

== Screenshots ==
* Screenshot 1: Setting for API Secret Key, Category Code and X Signature Key.
* Screenshot 2: Setting for Payment Amount field and ToyyibPay field.
* Screenshot 3: Sample form integrated with ToyyibPay.
* Screenshot 4: Sample ToyyibPay Payment Page.
* Screenshot 5: Sample return response.
* Screenshot 6: Sample entry on administration side.

== Changelog ==

= 3.8.1 =
* Ensure bill id matches with entry before processing.

= 3.8.0 =
* Based on PayPal Standard Addon 3.1
* Support for merge tag for Bill Description.
* This update may break your site. Only recommended for new installation.

== Installation ==
1. Install & Activate.
2. Forms >> Settings >> ToyyibPay >> Add New.
3. Insert your API Key & Category Code.
4. Update Settings.

== Frequently Asked Questions ==

= How to include Bill ID on payment notification? =

Set the tag {entry:transaction_id} at the event Payment Completion notification. You may refer to [GravityForms Merge Tag](https://docs.gravityforms.com/merge-tags/#entry-data) for more information.

= Where can I get API Secret & X Signature Key ? =

You can get the API Secret Key at your ToyyibPay Account Settings. [Get it here](https://toyyibpay.com/index.php/dashboard)

= Where can I get Category Code? =

You can get the Category Code at your ToyyibPay >> Billing. [Get it here](https://toyyibpay.com/index.php/category)

= Troubleshooting =

Known issues: Name with (Full) option will return null.

== Links ==
none

== Upgrade Notice ==

This update may break existing setup. Make sure you have a proper backup.
