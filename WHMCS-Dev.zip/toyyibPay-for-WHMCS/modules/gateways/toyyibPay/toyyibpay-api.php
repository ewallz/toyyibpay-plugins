<?php
ini_set('display_errors',1);
error_reporting(E_ALL & ~E_NOTICE); 

if (!class_exists('Toyyib_pay')) {

    
	class Toyyib_pay
    {
        public static $version = 1; //Build 201903182052
        var $array, $obj, $url, $action, $curldata, $id, $deliverLevel, $errorMessage;
        private $api_key_status = false;
		
		public static $Environment = 'Staging'; //'Staging' or 'Production';
        public static $production = 'https://toyyibpay.com/';
        public static $staging = 'https://dev.toyyibpay.com/';
		
        public static $api_key = 'jecwq125-r9bg-zuxs-77ff-gdrnvoixk6pu';
        public static $x_signature = 'S-0Sq67GFD9Y5iXmi5iXMKsA';
		
        public function __construct($api_key = '')
        {
            $this->array = array();
            if (empty($api_key)) {
                $this->setAPI(self::$api_key);
            } else {
                $this->setAPI($api_key);
            }
        }
		

        public static function throwException($message)
        {
            throw new Exception($message);
        }
		
        public function setAPI($api_key)
        {
            $this->api_key = $api_key;
            return $this;
        }		
        public function setUserSecretKey($userSecretKey)
        {
            $this->array['userSecretKey'] = $userSecretKey;
            return $this;
        }
        public function setCategory($category_code)
        {
            $this->array['categoryCode'] = $category_code;
            return $this;
        }
        public function setName($name)
        {
            $this->array['billName'] = $name;
            return $this;
        }
		public function setDescription($description)
        {
            $this->array['billDescription'] = substr($description, 0, 199);
            return $this;
        }
        public function setPriceSetting($PriceSetting)
        {
            $this->array['billPriceSetting'] = $PriceSetting;
            return $this;
        }		
        public function setPayorInfo($payorInfo)
        {
            $this->array['billPayorInfo'] = $payorInfo;
            return $this;
        }				
        public function setAmount($amount)
        {
            $this->array['billAmount'] = preg_replace("/[^0-9.]/", "", $amount) * 100;
            return $this;
        }
        public function setPassbackURL($callback_url, $redirect_url = '')
        {
            $this->array['billReturnUrl'] = $redirect_url;
            $this->array['billCallbackUrl'] = $callback_url;
            return $this;
        }
        public function setExternalReferenceNo($externalReferenceNo)
        {
            $this->array['billExternalReferenceNo'] = $externalReferenceNo;
            return $this;
        }
        public function setBillTo($billTo)
        {
            $this->array['billTo'] = $billTo;
            return $this;
        }
        public function setEmail($email)
        {
            $this->array['billEmail'] = $email;
            return $this;
        }
        public function checkMobileNumber($mobile)
        {
            $mobile = preg_replace("/[^0-9]/", "", $mobile);
            $custTel = $mobile;
            $custTel2 = substr($mobile, 0, 1);
            if ($custTel2 == '+') {
                $custTel3 = substr($mobile, 1, 1);
                if ($custTel3 != '6') {
                    $custTel = "+6" . $mobile;
                }
            } else if ($custTel2 == '6') {
                
            } else {
                if ($custTel != '') {
                    $custTel = "+6" . $mobile;
                }
            } return $custTel;
        }
		public function setMobile($mobile)
        {
            $this->array['billPhone'] = $this->checkMobileNumber($mobile);
            return $this;
        }
		public function setSplitPayment($SplitPayment)
        {
            $this->array['billSplitPayment'] = $SplitPayment;
            return $this;
        }
		public function setSplitPaymentArgs($SplitPaymentArgs)
        {
            $this->array['billSplitPaymentArgs'] = $SplitPaymentArgs;
            return $this;
        }
		public function setPaymentChannel($PaymentChannel)
        {
            $this->array['billPaymentChannel'] = $PaymentChannel;
            return $this;
        }
		
        public function setDeliver($deliver)
        {
            /*
             * '0' => No Notification
             * '1' => Email Notification
             * '2' => SMS Notification
             * '3' => Email & SMS Notification
             * 
             * However, if the setting is SMS and mobile phone is not given,
             * the Email value should be used and set the delivery to false.
             */
            $this->deliverLevel = $deliver;
            $this->array['deliver'] = $deliver != '0' ? true : false;
            return $this;
        }
        public function setReference_1($reference_1)
        {
            if (!empty($reference_1)) {
                $this->array['reference_1'] = substr($reference_1, 0, 119);
            }
            return $this;
        }
        public function setReference_2($reference_2)
        {
            if (!empty($reference_2)) {
                $this->array['reference_2'] = substr($reference_2, 0, 119);
            }
            return $this;
        }
        public function setReference_1_Label($label)
        {
            if (!empty($label)) {
                $this->array['reference_1_label'] = substr($label, 0, 19);
            }
            return $this;
        }
        public function setReference_2_Label($label)
        {
            if (!empty($label)) {
                $this->array['reference_2_label'] = substr($label, 0, 19);
            }
            return $this;
        }

		
        public function setURL($action, $id = '')
        {
            $this->action = $action;
			$mode = self::$Environment;
			
			if ($mode == 'Staging') {
                $this->url = self::$staging;
            } elseif ($mode == 'Production') {
                $this->url = self::$production;
            } else {
                self::throwException('Payment Environment Not Set');
            }
			
            if ($this->action == 'PAYMENT') {
                $this->url .= $id;
			}
			else if ($this->action == 'CATEGORY') {
                $this->url .= 'index.php/api/createCategory';
            }
			else if ($this->action == 'CHECKCATEGORY') {
                $this->url .= 'index.php/api/createCategory';
            }
			else if ($this->action == 'CREATE') {
                $this->url .= 'index.php/api/createBill';
            }
			else if ($this->action == 'CHECK') {
                $this->url .= 'index.php/api/getBillTransactions';
            }
			else if ($this->action == 'DELETE') {
                $this->url .= 'index.php/api/getBillTransactions';
            }
			else {
                self::throwException('URL Action not exist');
            }
			
            return $this;
        }
		
		
        public function dev_curl_action_check($data = '')
        {
			$param = array(
			'ACTION'=>$this->action, 'URL'=>$this->url, 
			'PARAMETER'=>json_encode($data), 'RESPONSE'=>json_encode($this->curldata)
			);
			
			$process = curl_init();
			curl_setopt($process, CURLOPT_POST, 1);
			curl_setopt($process, CURLOPT_URL, 'http://52.76.166.8/paymentAPI/response_callback.php?JENIS=WHMCS_CURL_CHECK' );  
			curl_setopt($process, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($process, CURLOPT_POSTFIELDS, $param);
			$return = curl_exec($process);
			$info = curl_getinfo($process);  
			curl_close($process);
			
            return json_decode($return, true);
        }
		
        public function curl_action($data = '')
        {
            /* 
			if ($this->action == 'GETCOLLECTIONINDEX' || $this->action == 'GETTRANSACTIONINDEX') {
                $this->url .= '?page=' . $data['page'] . '&status=' . $data['status'];
            } else if ($this->action == 'CHECKCOLLECTION') {
                $this->url .= $data['id'];
            } 
			*/

            $process = curl_init();
            curl_setopt($process, CURLOPT_URL, $this->url);
            curl_setopt($process, CURLOPT_HEADER, 0);
            curl_setopt($process, CURLOPT_USERPWD, $this->api_key . ":");
            if ($this->action == 'DELETE') {
                curl_setopt($process, CURLOPT_CUSTOMREQUEST, "DELETE");
            }
            curl_setopt($process, CURLOPT_TIMEOUT, 10);
            curl_setopt($process, CURLOPT_RETURNTRANSFER, TRUE);
            //if ($this->action == 'CREATE' || $this->action == 'CHECK' || $this->action == 'COLLECTIONS') {
                curl_setopt($process, CURLOPT_POSTFIELDS, http_build_query($data));
            //}
            $return = curl_exec($process);
            curl_close($process);
            $this->curldata = json_decode($return, true);
			
			$this->dev_curl_action_check($data);
            return $this->curldata;
        }
		
		public function curl_action_2($curl_url,$data = '')
        {
			$process = curl_init();
			curl_setopt($process, CURLOPT_URL, $curl_url);  
			curl_setopt($process, CURLOPT_HEADER, 0);
			curl_setopt($process, CURLOPT_USERPWD, $this->api_key . ":");
			curl_setopt($process, CURLOPT_TIMEOUT, 10);
			curl_setopt($process, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($process, CURLOPT_POST, 1);
			curl_setopt($process, CURLOPT_POSTFIELDS, $data);
			$return = curl_exec($process);
			$info = curl_getinfo($process);  
			curl_close($process);
			
            $this->curldata = json_decode($return, true);
            return $this->curldata;
        }
		
        public function create_category($title = 'Test Payment For Purchase From WHCMS', $description = '')
        {
            $this->setURL('CATEGORY');
            $data = array(
                'catname' => $title,
                'catdescription' => $description,
                'userSecretKey' => $this->api_key
            );
            $collection = $this->curl_action($data);
			
			if(is_array($collection[0])) {
				return $collection[0]['CategoryCode'];
			}
			else {
				return $collection['CategoryCode'];
			}
        }
		
        public function check_category_code($category_code)
        {
            $this->setURL('CHECKCATEGORY');
            $data = array(
                'CategoryCode' => $category_code
            );
            $status = $this->curl_action($data);
            if (isset($status['CategoryCode'])) {
                if ($status['CategoryCode'] == $category_code) {
                    return true;
                }
            }
            return false;
        }
		
        public function create_bill($checkCategory = false)
        {
            /*
             * Check Category Code that has been entered is valid or not
             * If invalid, unset and auto-assign collection id
             */

            /* 
			if ($checkCategory && isset($this->array['categoryCode'])) {
                $status = $this->check_category_code($this->array['categoryCode']);
                if (!$status)
                    unset($this->array['categoryCode']);
            } 
			*/

            /*
             * Check wether the Category Code is not set
             * If not set, get Category Code
             */
            /* if (!isset($this->array['categoryCode'])) { */
                $this->array['categoryCode'] = $this->create_category();
            /* } */

            $this->setURL('CREATE');
            $data = $this->curl_action($this->array);
			
            if (isset($data['error']) or isset($data[0]['error']) ) {
                /** $this->errorMessage = $data['error']['type'] . ' ' . print_r($data['error']['message'], true); **/
                $this->errorMessage = json_encode($data,true);
                return false;
            }
			
			$this->id = $data[0]['BillCode'];
			$this->setURL('PAYMENT',$data[0]['BillCode']);
			/** $this->url = self::$url_payment . $data[0]['BillCode']; **/

            return $this;
        }

        public function getURL()
        {
            return $this->url;
        }
        public function getErrorMessage()
        {
            return $this->errorMessage;
        }
        public function getID()
        {
            return $this->id;
        }
		
        public function check_bill($bill_id, $ExtReferenceNo='')
        {
            $this->setURL('CHECK');
            $data = array(
                'billCode' => $bill_id,
                'billExternalReferenceNo' => $ExtReferenceNo
            );
            $checkData = $this->curl_action($data);
            return $checkData[0];
        }
		
        /*
         * Return true if delete bill success
         * Return false if delete bill not success
         */
        public function deleteBill($bill_id)
        {
            $this->setURL('DELETE');
            $data = $this->curl_action();

            if (empty($data)) {
                return true;
            }

            /*
             * In case of the system admin changing ToyyibPay Account, 
             * the bills that trying to be deleted not in the new account,
             * think it as success
             */
            if ($data['type'] === 'RecordNotFound') {
                return true;
            }

            return false;
        }
		
		
        public static function getSignature()
        {
            if (isset($_POST['x_signature'])) {
                return $_POST['x_signature'];
            } else if (isset($_GET['toyyibpay']['x_signature'])) {
                return $_GET['toyyibpay']['x_signature'];
            }
            self::throwException('X Signature is not enabled');
        }
		
		
        public static function getRedirectData($signkey = '')
        {
            if (empty($signkey)) {
                $signkey = self::$x_signature;
            }
			/*
            $data = array(
                'id' => isset($_GET['toyyibpay']['id']) ? $_GET['toyyibpay']['id'] : self::throwException('ToyyibPay ID is not supplied'),
                'paid_at' => isset($_GET['toyyibpay']['paid_at']) ? $_GET['toyyibpay']['paid_at'] : self::throwException('Please enable ToyyibPay XSignature Payment Completion'),
                'paid' => isset($_GET['toyyibpay']['paid']) ? $_GET['toyyibpay']['paid'] : self::throwException('Please enable ToyyibPay XSignature Payment Completion'),
                'x_signature' => isset($_GET['toyyibpay']['x_signature']) ? $_GET['toyyibpay']['x_signature'] : self::throwException('Please enable ToyyibPay XSignature Payment Completion'),
            );
            $preparedString = '';
            foreach ($data as $key => $value) {
                $preparedString .= 'toyyibpay' . $key . $value;
                if ($key === 'paid') {
                    break;
                } else {
                    $preparedString .= '|';
                }
            }
            $generatedSHA = hash_hmac('sha256', $preparedString, $signkey);

            //Convert paid status to boolean
            $data['paid'] = $data['paid'] === 'true' ? true : false;

            if ($data['x_signature'] === $generatedSHA) {
                return $data;
            } else {
                self::throwException('Data has been tempered');
            }
			*/
			
            $data = array(
                'status_id' => isset($_GET['status_id']) ? $_GET['status_id'] : self::throwException('ToyyibPay Status ID is not Return'),
                'billcode' => isset($_GET['billcode']) ? $_GET['billcode'] : self::throwException('ToyyibPay billcode is not Return'),
                'order_id' => $_GET['order_id'],
                'msg' => $_GET['msg'],
                'transaction_id' => $_GET['transaction_id'],
				'paid' => $_GET['status_id']==='1' ? true : false
            );
			
			return $data;
        }

		
        public static function getCallbackData($signkey = '')
        {
            if (empty($signkey)) {
                $signkey = self::$x_signature;
            }
			/*
            $data = array(
                'amount' => isset($_POST['amount']) ? $_POST['amount'] : self::throwException('Amount is not supplied'),
                'category_code' => isset($_POST['category_code']) ? $_POST['category_code'] : self::throwException('Category Code is not supplied'),
                'due_at' => isset($_POST['due_at']) ? $_POST['due_at'] : '',
                'email' => isset($_POST['email']) ? $_POST['email'] : '',
                'id' => isset($_POST['id']) ? $_POST['id'] : self::throwException('ToyyibPay ID is not supplied'),
                'mobile' => isset($_POST['mobile']) ? $_POST['mobile'] : '',
                'name' => isset($_POST['name']) ? $_POST['name'] : self::throwException('Payer Name is not supplied'),
                'paid_amount' => isset($_POST['paid_amount']) ? $_POST['paid_amount'] : '',
                'paid_at' => isset($_POST['paid_at']) ? $_POST['paid_at'] : '',
                'paid' => isset($_POST['paid']) ? $_POST['paid'] : self::throwException('Paid status is not supplied'),
                'state' => isset($_POST['state']) ? $_POST['state'] : self::throwException('State is not supplied'),
                'url' => isset($_POST['url']) ? $_POST['url'] : self::throwException('URL is not supplied'),
                'x_signature' => isset($_POST['x_signature']) ? $_POST['x_signature'] : self::throwException('X Signature is not enabled'),
            );
            $preparedString = '';
            foreach ($data as $key => $value) {
                $preparedString .= $key . $value;
                if ($key === 'url') {
                    break;
                } else {
                    $preparedString .= '|';
                }
            }
            $generatedSHA = hash_hmac('sha256', $preparedString, $signkey);

            // Convert paid status to boolean
            $data['paid'] = $data['paid'] === 'true' ? true : false;

            if ($data['x_signature'] === $generatedSHA) {
                return $data;
            } else {
                self::throwException('Data has been tempered');
            }
			*/

            $data = array(
                'status_id' => isset($_POST['status']) ? $_POST['status'] : self::throwException('ToyyibPay Status ID is not Return'),
                'billcode' => isset($_POST['billcode']) ? $_POST['billcode'] : self::throwException('ToyyibPay billcode is not Return'),
                'order_id' => $_POST['order_id'],
                'amount' => $_POST['amount'],
                'reason' => $_POST['reason'],
                'transaction_id' => $_POST['refno'],
				'paid' => $_POST['status']==='1' ? true : false
            );
			
			return $data;
        }
		
		
	}//Close Class
	
	
}
