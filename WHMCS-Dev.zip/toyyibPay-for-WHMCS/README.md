# ToyyibPay for WHMCS

Accept payment using ToyyibPay by using this plugin.

# System Requirement

* PHP 5.6, **7.0 (Recommended)**
* WHMCS v6.x, v7.x


# Configuration

1. Go to WHMCS Administration
2. Setup >> Payments >> Payment Gateways
3. Set **API Key** & **X Signature Key**
4. Set **Convert to Processing** to **MYR**
4. Save

