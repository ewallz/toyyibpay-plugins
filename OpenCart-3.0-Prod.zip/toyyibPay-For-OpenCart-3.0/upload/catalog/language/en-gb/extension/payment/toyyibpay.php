<?php
/**
 * ToyyibPay OpenCart Plugin
 * 
 * @package Payment Gateway
 * @author ToyyibPay Team
 */
 
// Text
$_['text_title'] = 'ToyyibPay. Fair Payment Software';