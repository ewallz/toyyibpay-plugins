# ToyyibPay for Easy Digital Downloads (EDD)

Accept Payment using ToyyibPay by using this plugin

## System Requirements
* PHP Version **5.6** or later
* Build with **Easy Digital Downloads** version **2.9.7**

## Configuration

1. **Downloads** >> **Settings** >> **Payment Gateways**
2. **Tick ToyyibPay** and Set **API Key**, **Category Code** 
3. Save Changes

Note: Make sure your Currency is set to **Malaysian Ringgits** otherwise it will not work.
