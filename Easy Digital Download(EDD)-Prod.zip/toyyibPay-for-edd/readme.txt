=== ToyyibPay for Easy Digital Downloads ===
Contributors: ToyyibPayTeam
Tags: toyyibpay,paymentgateway,fpx,boost,mastercard,visa
Tested up to: 4.9.8
Stable tag: 3.0.4
Donate link: https://toyyibpay.com/
Requires at least: 4.8
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 5.5

Accept Internet Banking Payment by using ToyyibPay.

== Description ==
Install this plugin to accept payment using ToyyibPay.
With this ToyyibPay Easy Digital Downloads payment gateway plugin, you will be able to accept the following payment methods in your shop:
* __Bank Account(FPX)__
* __MasterCard__
* __Visa__


== Upgrade Notice ==

None

== Screenshots ==

* Configuration page for setting up ToyyibPay API Credentials.

== Changelog ==

= 1.0.0 =
* Build 201904081105 : Release plugin for dev. version
* Build 201904081120 : Release plugin for prod. version

== Installation ==

= Automatic Installation =
* 	Login to your WordPress Admin area
* 	Go to "Plugins > Add New" from the left hand menu
* 	In the search box type __ToyyibPay Easy Digital Downloads payment gateway__
*	From the search result you will see __ToyyibPay Easy Digital Downloads payment gateway__ click on __Install Now__ to install the plugin
*	A popup window will ask you to confirm your wish to install the Plugin.
*	After installation, activate the plugin.
* 	Open the settings page for Easy Digital Downloads  and click the "Payment Gateways" tab.
*	Insert your **API Secret Key** under ToyyibPay Payment Gateway Settings
* 	Click "Saved Changes"

= Manual Installation =
1. 	Download the plugin zip file
2. 	Login to your WordPress Admin. Click on "Plugins > Add New" from the left hand menu.
3.  Click on the "Upload" option, then click "Choose File" to select the zip file from your computer. Once selected, press "OK" and press the "Install Now" button.
4.  Activate the plugin.
5. 	Open the settings page for Easy Digital Downloads  and click the "Payment Gateways" tab.
6.	Insert your **API Secret Key** under ToyyibPay Payment Gateway Settings
7. 	Click "Saved Changes"


== Frequently Asked Questions ==

= Where can I get API Secret Key? =

You can the API Secret Key at your ToyyibPay Dashboard >> Settings. [Get it here](https://toyyibpay.com/index.php/dashboard)


== Links ==
[Sign Up](https://toyyibpay.com/access) for ToyyibPay account to accept payment using ToyyibPay now!
