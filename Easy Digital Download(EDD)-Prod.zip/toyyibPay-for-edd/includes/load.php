<?php

use ToyyibPay\EDD\ToyyibPayAPI;

// registers the gateway
function toyyibpay_edd_register_gateway($gateways)
{
    $display_name = edd_get_option('toyyibpay_display_name', false);

    if (!$display_name) {
        $display_name = __('ToyyibPay', 'eddtoyyibpayplugin');
    }
    $gateways['toyyibpay'] = array('admin_label' => 'ToyyibPay', 'checkout_label' => $display_name);
    return $gateways;
}
add_filter('edd_payment_gateways', 'toyyibpay_edd_register_gateway');

function pw_edd_toyyibpay_cc_form()
{
    // register the action to remove default CC form
    return;
}
add_action('edd_toyyibpay_cc_form', 'pw_edd_toyyibpay_cc_form');

function toyyibpay_process_payment($purchase_data)
{
    if (! wp_verify_nonce($purchase_data['gateway_nonce'], 'edd-gateway')) {
        wp_die(__('Nonce verification has failed', 'easy-digital-downloads'), __('Error', 'easy-digital-downloads'), array( 'response' => 403 ));
    }

    // payment processing happens here
    global $edd_options;
    $purchase_summary = edd_get_purchase_summary($purchase_data);

    /**********************************
    * setup the payment details
    **********************************/

    $payment = array(
        'price' => $purchase_data['price'],
        'date' => $purchase_data['date'],
        'user_email' => $purchase_data['user_email'],
        'purchase_key' => $purchase_data['purchase_key'],
        'currency' => $edd_options['currency'],
        'downloads' => $purchase_data['downloads'],
        'cart_details' => $purchase_data['cart_details'],
        'user_info' => $purchase_data['user_info'],
        'status' => 'pending'
    );
	
    // record the pending payment
    $payment_id = edd_insert_payment($payment);

    $parameter = array(
		'userSecretKey'=> edd_get_option('toyyibpay_api_key', false),
		'categoryCode'=> edd_get_option('toyyibpay_category_code', false),
		'billName'=> 'Payment ' . $payment_id . ' : ' . $payment['user_info']['first_name'] . ' ' . $payment['user_info']['last_name'],
		'billDescription'=> mb_substr($purchase_summary, 0, 200),
		'billPriceSetting'=>1,
		'billPayorInfo'=>1, 
		'billAmount'=> strval($payment['price'] * 100),
		'billReturnUrl'=> toyyibpay_edd_listener_url(),
		'billCallbackUrl'=> toyyibpay_edd_listener_url(),
		'billExternalReferenceNo'=> $payment_id,
		'billTo'=> $payment['user_info']['first_name'] . ' ' . $payment['user_info']['last_name'],
		'billEmail'=> $payment['user_email'],
		'billPhone'=>'60',
		'billSplitPayment'=>0,
		'billSplitPaymentArgs'=>'',
		'billPaymentChannel'=>2,
        'billCurrency' => $payment['currency']
    );

    $api_key = edd_get_option('toyyibpay_api_key', false);
	
    $toyyibpay = new ToyyibPayAPI($api_key);
    list($rheader, $rbody) = $toyyibpay->createBill($parameter);

    if ($rheader !== 200) {
        wp_die(__('Something went wrong! ' . print_r($rbody, true) , 'eddtoyyibpayplugin'));
    }

    if ( empty($rbody[0]['BillCode']) ) {
        wp_die(__('BillCode Not Exist! ' . print_r($rbody, true) , 'eddtoyyibpayplugin'));
        //wp_die(__('Something went wrong! ' . print_r($rbody, true) . (is_array($rbody) ? '=is_array' : '=not_Array') , 'eddtoyyibpayplugin'));
        //wp_die(__('Something went wrong! ' . '<pre>' . print_r($purchase_data, true) . print_r($payment, true) . print_r($parameter, true) . print_r($rbody, true) . '</pre>', 'eddtoyyibpayplugin'));
    }

    if (! add_post_meta($payment_id, 'toyyibpay_id', $rbody[0]['BillCode'], true)) {
        update_post_meta($payment_id, 'toyyibpay_id', $rbody[0]['BillCode']);
    }
    if (! add_post_meta($payment_id, 'toyyibpay_extrefno', $rbody[0]['BillCode'], true)) {
        update_post_meta($payment_id, 'toyyibpay_extrefno', $rbody[0]['BillCode']);
    }
    if (! add_post_meta($payment_id, 'toyyibpay_api_key', $api_key, true)) {
        update_post_meta($payment_id, 'toyyibpay_api_key', $api_key);
    }
    if (! add_post_meta($payment_id, 'toyyibpay_paid', 'false', true)) {
        update_post_meta($payment_id, 'toyyibpay_paid', 'false');
    }

    // Redirect to ToyyibPay
    wp_redirect($rbody[0]['BillURL']);
    exit;
}
add_action('edd_gateway_toyyibpay', 'toyyibpay_process_payment');

function toyyibpay_edd_listener_url()
{
    $passphrase = get_option('toyyibpay_edd_listener', false);
    if (!$passphrase) {
        $passphrase = md5(site_url() . time());
        update_option('toyyibpay_edd_listener', $passphrase);
    }
    return add_query_arg('toyyibpay_edd_action', $passphrase, site_url('/'));
}

// adds the settings to the Payment Gateways section
function toyyibpay_edd_add_settings($settings)
{
    $toyyibpay_gateway_settings = array(
        array(
            'id' => 'toyyibpay_settings',
            'name' => '<strong>' . __('ToyyibPay Payment Gateway Settings', 'eddtoyyibpayplugin') . '</strong>',
            'desc' => __('Configure ToyyibPay Payment Gateway Settings', 'eddtoyyibpayplugin'),
            'type' => 'header'
        ),
        array(
            'id' => 'toyyibpay_display_name',
            'name' => __('ToyyibPay Display Name', 'eddtoyyibpayplugin'),
            'desc' => __('Display name on user checkout.', 'eddtoyyibpayplugin'),
            'type' => 'text',
            'size' => 'regular'
        ),
        array(
            'id' => 'toyyibpay_api_key',
            'name' => __('API Secret Key', 'eddtoyyibpayplugin'),
            'desc' => __('[Mandatory] Get Your API Key at <a href="https://toyyibpay.com/index.php/dashboard" target="_blank">ToyyibPay</a> >> Dashboard >> Settings', 'eddtoyyibpayplugin'),
            'type' => 'text',
            'size' => 'regular'
        ),
        array(
            'id' => 'toyyibpay_category_code',
            'name' => __('Category Code', 'eddtoyyibpayplugin'),
            'desc' => __('[Optional] Get Your Category Code at <a href="https://toyyibpay.com/index.php/category" target="_blank">ToyyibPay</a> >> Category', 'eddtoyyibpayplugin'),
            'type' => 'text',
            'size' => 'regular'
        )
    );

    return array_merge($settings, $toyyibpay_gateway_settings);
}
add_filter('edd_settings_gateways', 'toyyibpay_edd_add_settings');

function edd_listen_for_toyyibpay_ipn()
{
    if (!isset($_GET['toyyibpay_edd_action'])) {
		return;
    }
    $passphrase = get_option('toyyibpay_edd_listener', false);
    if (!$passphrase) {
		echo "Error : Please check your EDD log";
		edd_debug_log('ToyyibPay toyyibpay_edd_listener passphrase not found in your database! Failed to update payment to your system.');
		return;
    }
    if ($_GET['toyyibpay_edd_action'] != $passphrase) {
        //echo $_GET['toyyibpay_edd_action'] .' == '. $passphrase;
		echo "Error : Please check your EDD log";
		edd_debug_log('ToyyibPay Return URL are invalid! Failed to update payment to your system.');
		return;
    }

    $api_key = edd_get_option('toyyibpay_api_key', false);
	$toyyibpay = new ToyyibPayAPI($api_key);
	
    try {
		$data = $toyyibpay->getTransactionData();
        if ($data['type'] === 'callback') {
            edd_debug_log('ToyyibPay IPN endpoint loaded & verified successfully');
        }
    } catch (\Exception $e) {
        edd_record_gateway_error(__('IPN Error', 'easy-digital-downloads'), sprintf(__('Invalid IPN verification response. IPN data: %s', 'easy-digital-downloads'), $e->getMessage()));
        edd_debug_log('Invalid IPN verification response. IPN data: ' . $e->getMessage());
        exit($e->getMessage());
    }
	
	//Check
	/* $dataCheck = array(
		'Response'=> json_encode($data)
	);
	$toyyibpay->temp_dev_action_check($dataCheck,$data['type']); */
		
	
    $payment_id = absint($data['order_id']);
    $payment = new EDD_Payment($payment_id);
    if ($payment->gateway != 'toyyibpay') {
		return; // this isn't a ToyyibPay IPN
    }

    if ('myr' != strtolower($payment->currency)) {
        edd_record_gateway_error(__('IPN Error', 'easy-digital-downloads'), sprintf(__('Invalid currency setup. IPN data: %s', 'easy-digital-downloads'), json_encode($data)), $payment_id);
        edd_debug_log('Invalid currency setup. IPN data: ' . print_r($data, true));
        edd_update_payment_status($payment_id, 'failed');
        edd_insert_payment_note($payment_id, __('Payment failed due to invalid currency setup.', 'easy-digital-downloads'));
		
        return;
    }
	
	$success = $data['paid'];	
    if( $success ) {
        if (get_post_status($payment_id) == 'publish') {
            // Do nothing
        } else {
			// Retrieve the total purchase amount (before ToyyibPay)
            $payment_amount = edd_get_payment_amount($payment_id);

            if (number_format((float) $data['amount'], 2) < number_format((float) $payment_amount, 2)) {

                // The prices don't match
                edd_record_gateway_error(__('IPN Error', 'easy-digital-downloads'), sprintf(__('Invalid payment amount in IPN response. IPN data: %s', 'easy-digital-downloads'), json_encode($data)), $payment_id);
                edd_debug_log('Invalid payment amount in IPN response. IPN data: ' . printf($data, true));
                edd_update_payment_status($payment_id, 'failed');
                edd_insert_payment_note($payment_id, __('Payment failed due to invalid amount in ToyyibPay IPN.', 'easy-digital-downloads'));
                return;
            }
			
            edd_insert_payment_note($payment_id, sprintf(__('ToyyibPay Bill ID: %s', 'easy-digital-downloads'), $data['billcode']));
            edd_set_payment_transaction_id($payment_id, $data['billcode']);
            edd_update_payment_status($payment_id, 'publish');
            update_post_meta($payment_id, 'toyyibpay_paid', 'true');

        }
    }

    if ($data['type'] === 'redirect' && $success ) {
        edd_send_to_success_page();
    } elseif ($data['type'] === 'redirect' && !$success) {
        //edd_send_back_to_checkout('?payment-mode=' . $purchase_data['post_data']['edd-gateway']);
        header('Location: '.edd_get_failed_transaction_uri('?payment-id=' . $payment_id));
    }

    exit('Successful Callback');
}

add_action('init', 'edd_listen_for_toyyibpay_ipn');

function edd_toyyibpay_delete_bill($post_id)
{
    $post_type = get_post_type($post_id);

    if ($post_type !== 'edd_payment') {
        return;
    }

    /* Allow hack to disable bill deletion */
    if (defined('BEDD_DISABLE_DELETE') && BEDD_DISABLE_DELETE) {
        return;
    }
    $bill_id = get_post_meta($post_id, 'toyyibpay_id', true);
    $api_key = get_post_meta($post_id, 'toyyibpay_api_key', true);
    $status  = get_post_meta($post_id, 'toyyibpay_paid', true);

    if (empty($bill_id) || empty($api_key) || empty($status)) {
        return;
    }

    if ($status === 'true') {
        delete_post_meta($post_id, 'toyyibpay_id');
        delete_post_meta($post_id, 'toyyibpay_api_key');
        delete_post_meta($post_id, 'toyyibpay_paid');
        return;
    }

	$toyyibpay = new ToyyibPayAPI($api_key);
    
	//del bill
	$parameter = array(
		'billCode' => $bill_id,
		'billExternalReferenceNo' => $post_id
	);
	list($rheader, $rbody) = $toyyibpay->deleteBill($parameter);
    if ($rheader !== 200) {
        list($rheader, $rbody) = $toyyibpay->checkBill($parameter);
        if (!$rbody['billpaymentStatus']=='1') {
            wp_die(__('Bill cannot be deleted. Message: ' . print_r($rbody, true), 'eddtoyyibpayplugin'));
        }
    }
}

/*
 * Delete Bills before deleting pending payment
 */
add_action('before_delete_post', 'edd_toyyibpay_delete_bill', 10, 1);
