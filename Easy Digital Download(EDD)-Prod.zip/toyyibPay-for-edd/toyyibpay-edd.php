<?php
/*
    Plugin Name:       ToyyibPay for Easy Digital Downloads
    Plugin URL:        https://toyyibpay.com
    Description:       ToyyibPay Payment Gateway | Accept Payment using all participating FPX Banking Channels & Debit/Credit card. <a href="https://toyyibpay.com/access" target="_blank">Register Now</a>.
    Version:           1.0.0
    Author:            ToyyibPay Team
    Author URI:        https://toyyibpay.com
    License:           GPL-3.0-or-later
	Requires PHP: 	   5.6 or later
*/

//error_reporting(E_ALL);
//ini_set('display_errors', 'On');
//define('BEDD_DISABLE_DELETE', true);

// Main Reference: https://pippinsplugins.com/create-custom-payment-gateway-for-easy-digital-downloads/

require 'includes/toyyibpayAPI.php';

if (!function_exists('gourl_edd_gateway_load') && !function_exists('gourl_edd_action_links')) { // Exit if duplicate
    require 'includes/load.php';
}

function typ_edd_plugin_settings_link($links)
{
    $settings_link = '<a href="edit.php?post_type=download&page=edd-settings&tab=gateways">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

$plugin_action_link = 'plugin_action_links_'.plugin_basename(__FILE__);
add_filter($plugin_action_link, 'typ_edd_plugin_settings_link');
