<?php
// Reference: http://docs.whmcs.com/Using_Models
// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
require_once __DIR__ . '/toyyibpay-api.php';

// Get variable for WHMCS configuration
global $CONFIG;

// Import namespace for Database
use WHMCS\Billing\Payment\Transaction;

// Module name.
$gatewayModuleName = 'toyyibPay';

// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);

// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}

// Get payment gateway details
$api_key = $gatewayParams['toyyibpay_api_key'];
$x_signature = $gatewayParams['toyyibpay_x_signature_key'];

// Retrieve data returned in payment gateway return
try {
    $data = Toyyib_pay::getRedirectData($x_signature);
} catch (\Exception $e) {
    exit($e->getMessage());
}

$toyyibpay = new Toyyib_pay($api_key);

//Validate the status from ID
$moreData = $toyyibpay->check_bill($data['billcode'],$data['order_id']);

// Collect data
$success = $data['paid'];
$invoiceId = $data['order_id'];
//$transactionId = $data['transaction_id'];
$transactionId = $data['billcode'];

//$invoiceId = $moreData['reference_1'];
//$paymentAmount = number_format(($moreData['amount'] / 100), 2);
$paymentAmount = $moreData['billpaymentAmount'];
$paymentFee = 0;

if( $success ) {
	$transactionState = 'Success';
}
else {
	if( $data['status_id'] != '1' ) {
		$success = $moreData['billpaymentStatus']==='1' ? true : false;
	}
	if( $moreData['billpaymentStatus']=='1' ) $transactionState = 'Success';
	else if( $moreData['billpaymentStatus']=='2' ) $transactionState = 'Pending';
	else $transactionState = 'Unsuccessful';
}

//$hash = Toyyib_pay::getSignature();

/*
* Get Base Currency Amount
*/
/* if (!empty($moreData['reference_2'])) {
    $paymentAmount = $moreData['reference_2'];
} */

//$transactionState = $moreData['state'];

if ($success) {
    /**
     * Validate Callback Invoice ID.
     *
     * Checks invoice ID is a valid invoice number. Note it will count an
     * invoice in any status as valid.
     *
     * Performs a die upon encountering an invalid Invoice ID.
     *
     * Returns a normalized invoice ID.
     */
    $invoiceId = checkCbInvoiceID($invoiceId, $gatewayParams['name']);
    /**
     * Check ToyyibPay Bills ID.
     *
     * Performs a check for any existing transactions with the same given
     * transaction number.
     *
     * Don't update to db if already have.
     */
    //$sql = Transaction::where('transid', $data['id'])->get();
    $sql = Transaction::where('transid', $transactionId)->get();

    foreach ($sql as $data) {
        $result = $data->transid;
        break;
    }

    if (empty($result)) {
        $transactionStatus = 'Return: ' . $transactionState;

        /**
         * Add Invoice Payment.
         *
         * Applies a payment transaction entry to the given invoice ID.
         *
         * @param int $invoiceId         Invoice ID
         * @param string $transactionId  Transaction ID
         * @param float $paymentAmount   Amount paid (defaults to full balance)
         * @param float $paymentFee      Payment fee (optional)
         * @param string $gatewayModule  Gateway module name
         */
        addInvoicePayment($invoiceId, $transactionId, $paymentAmount, $paymentFee, $gatewayModuleName);

        // Log Transaction
        logTransaction($gatewayParams['name'], $_GET, $transactionStatus);
    }

    // Get success redirection path
    if ($gatewayParams['toyyibpay_success_path'] == 'viewinvoice') {
        $redirect_url = $CONFIG['SystemURL'] . '/viewinvoice.php?id=' . $invoiceId;
    } elseif ($gatewayParams['toyyibpay_success_path'] == 'listinvoice') {
        $redirect_url = $CONFIG['SystemURL'] . "/clientarea.php?action=invoices";
    } else {
        $redirect_url = $CONFIG['SystemURL'] . "/clientarea.php";
    }
} else {

    // Get failed redirection path
    if ($gatewayParams['toyyibpay_failed_path'] == 'viewinvoice') {
        $redirect_url = $CONFIG['SystemURL'] . '/viewinvoice.php?id=' . $invoiceId;
    } elseif ($gatewayParams['toyyibpay_failed_path'] == 'listinvoice') {
        $redirect_url = $CONFIG['SystemURL'] . "/clientarea.php?action=invoices";
    } else {
        $redirect_url = $CONFIG['SystemURL'] . "/clientarea.php";
    }
}
header("Location: " . $redirect_url);
